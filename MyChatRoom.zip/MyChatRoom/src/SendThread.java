import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
/**
 * 
 * Message send thread for client
 *
 */
public class SendThread implements Runnable{
	private BufferedReader console;
	private DataOutputStream dos;
	private Socket client;
	private boolean isRunning;
	private String username;
	
	//constructor
	public SendThread(Socket client, String username)
	{
		
		//read message from user's keyboard
		console = new BufferedReader(new InputStreamReader(System.in));
		this.isRunning = true;
		this.username = username;
		try 
		{
			//use client's dos
			dos = new DataOutputStream(client.getOutputStream());
			send(username);
		}catch(IOException e){
			System.out.println("ERROR: CLIENT DOS");
			this.release();
		}
	}
	
	private void send(String messageSent)
	{
		try
		{
			dos.writeUTF(messageSent);
			dos.flush();
		}catch(IOException e){
			System.out.println("ERROR: CLIENT send");
		}
	}
	
	private String getMessageSent()
	{
		try
		{
			return console.readLine();
		}catch(IOException e)
		{
			System.out.println("ERROR: CLIENT getMessageSent");
		}
		//default return empty
		return "";
	}
	
	@Override
	public void run() {
		while(isRunning)
		{
			String messageSent = getMessageSent();
			if(!messageSent.equals(""))
			{
				send(messageSent);
			}
		}
	}
	
	//release resources
	private void release()
	{
		this.isRunning = false;
		ChatUtil.close(dos);
		ChatUtil.close(client);
	}

	
}

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.CopyOnWriteArrayList;

public class Server {
	//a container that holds all clients IOChaneel
	private static CopyOnWriteArrayList<IOChannel> allClients =new CopyOnWriteArrayList<IOChannel>();
	
	public static void main(String[] args) throws IOException
	{
		System.out.println("****SERVER VIEW****");
		ServerSocket server = new ServerSocket(ChatUtil.PORT);
		
		//wait for users to connect
		while(true)
		{
			Socket client = server.accept();
			System.out.println("A user has connected.");
			//create IOChaneel for this client
			IOChannel ioc = new IOChannel(client);
			//add this client to the container
			allClients.add(ioc);
			new Thread(ioc).start();
		}
	}
	
	static class IOChannel implements Runnable{
		private DataInputStream dis;
		private DataOutputStream dos;
		private Socket client;
		private boolean isRunning;
		private String username;
		
		public IOChannel(Socket client)
		{	
			try {
				this.dos = new DataOutputStream(client.getOutputStream());
				this.dis = new DataInputStream(client.getInputStream());
				isRunning = true;
				this.username = serverReceive();
				serverSend("\"" + username + "\"" + " Welcome to the chat.");
				talkToOthers("\"" + username + "\"" + " has joined the chat.", true);
				
			} catch (IOException e) {
				
				System.out.println("ERROR: IOChannel Creation");
				release();
			}
		}
			
			
		private void serverSend(String sysInfo)
		{
			try
			{
				dos.writeUTF(sysInfo);
			}catch(IOException e)
			{					
				System.out.println("ERROR: serverSend");
				release();
			}
		}
		
		private String serverReceive()
		{
			String messageReceived = "";
			try
			{
				messageReceived = dis.readUTF();
			}catch(IOException e)
			{
				System.out.println("A user has disconnected.");
				release();
			}
			return messageReceived;
		}
		
		//manage messages
		//distinguish between group chat and private chat
		private void talkToOthers(String messageSent, boolean isSys)
		{
			//private chat format:
			//@username:message
			boolean isPrivateMsg = messageSent.startsWith("@");
			if(isPrivateMsg) { 
				int msgStartIndex =messageSent.indexOf(":");
				//retrieve the target username
				String targetUsername = messageSent.substring(1,msgStartIndex);
				//retrieve the message being sent
				messageSent = messageSent.substring(msgStartIndex+1);
				//loop through all IOChannels and find the target IOChannel
				for(IOChannel other: allClients) {
					if(other.username.equals(targetUsername)) {//target
						other.serverSend("\"" + this.username + "\"" +" sends you a private message: "+ messageSent);
						break;
					}
				}
			//group chat
			}else {				
				for(IOChannel other: allClients) {
					if(other==this) { 
						continue;
					}
					if(!isSys) {
						other.serverSend(this.username +" to everyone: "+ messageSent);
					}else {
						other.serverSend(messageSent); //system message
					}
				}
			}
		}
		
		private void release()
		{
			this.isRunning = false;
			ChatUtil.close(dis);
			ChatUtil.close(dos);
			ChatUtil.close(client);
			allClients.remove(this);
			talkToOthers(this.username+" has left the chat.", true);
		}


		@Override
		public void run() {
			while(isRunning) {
				String msg = serverReceive() ;
				if(!msg.equals(""))
				{
					talkToOthers(msg, false);
				}
			}
		}
		
		
	}//class IOChaneel ends here
}//class server ends here
		
		


import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class ReceiveThread implements Runnable{
	
	private DataInputStream dis;
	private Socket client;
	private boolean isRunning;
	private String username;
	
	public ReceiveThread(Socket client, String username)
	{
		this.client = client;
		this.username = username;
		this.isRunning = true;
		try {
			dis =new DataInputStream(client.getInputStream());
		} catch (IOException e) {
			System.out.println("ERROR: client receieve constructor");
			release();
		}
	}
	
	public String receive()
	{
		String messageReceived = "";
		try
		{
			messageReceived = dis.readUTF();
		}catch(IOException e)
		{
			System.out.println("ERROR: client receive");
			release();
		}
		return messageReceived;
	}

	@Override
	public void run() {
		while(isRunning)
		{
			String messageReceived = receive();
			if(!messageReceived.equals(""))
			{
				System.out.println(messageReceived);
			}
		}
		
	}
	
	public void release()
	{
		this.isRunning = false;
		ChatUtil.close(dis);
		ChatUtil.close(client);
	}

}

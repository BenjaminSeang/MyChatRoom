import java.io.Closeable;

public class ChatUtil {
	
	final static int PORT = 5555;
	
	public static void close(Closeable closeMe) {
		try
		{
			if(closeMe != null)
			{
				closeMe.close();
			}
			
		}catch(Exception e){
			System.out.println("ERROR: THREAD CLOSURE");
		}
	}
}

